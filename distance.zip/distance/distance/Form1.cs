﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace distance
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] firstpointvalue = textBox1.Text.Split(",");
            string[] secondpointvalue = textBox2.Text.Split(",");
            double euclideandistance = 0;
            double manhattan = 0;
            double sumofxy = 0;
            double sumofsquareofx = 0;
            double sumofsquareofy = 0;
            int i = 0;
            foreach(string s in firstpointvalue)
            {
                euclideandistance = euclideandistance + Math.Pow(double.Parse(s) - double.Parse(secondpointvalue[i]), 2);
                manhattan = manhattan + Math.Abs(double.Parse(s) - double.Parse(secondpointvalue[i]));
                sumofxy = sumofxy + (double.Parse(s) * double.Parse(secondpointvalue[i]));
                sumofsquareofx = sumofsquareofx + Math.Pow(double.Parse(s), 2);
                sumofsquareofy=sumofsquareofy+ Math.Pow(double.Parse(secondpointvalue[i]), 2);
                i = i + 1;
            }
            double cosinecorrelation = sumofxy / (Math.Sqrt(sumofsquareofy) * Math.Sqrt(sumofsquareofx));
            MessageBox.Show("Cosine Coreelation" + cosinecorrelation);
            MessageBox.Show("Euclidean Distance" + Math.Sqrt(euclideandistance));
            MessageBox.Show("Manhattan " + manhattan);
        }
    }
}
